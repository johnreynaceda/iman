@section('title', 'Transaction History')
<x-employee-layout>
  <div class="bg-white">
    <main class="mx-auto max-w-2xl px-4 mt-2 py-6  sm:px-6 lg:max-w-7xl lg:px-8">
      <livewire:employee.history />
    </main>
  </div>

</x-employee-layout>
