<div class="ml-3">

  <x-button label="View Borrowers" icon="eye" wire:click="viewBorrower({{ $getState() }})"
    spinner="viewBorrower({{ $getState() }})" positive rounded sm />


</div>
