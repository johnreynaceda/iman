@section('title', 'Borrowed Assets')
<x-admin-layout>
  <livewire:admin.borrowed-asset />
</x-admin-layout>
