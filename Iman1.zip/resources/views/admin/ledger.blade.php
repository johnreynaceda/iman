@section('title', 'Ledger')
<x-admin-layout>
  <livewire:admin.ledger />
</x-admin-layout>
