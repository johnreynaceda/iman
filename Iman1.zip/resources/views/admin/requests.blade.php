@section('title', 'Requested Assets')
<x-admin-layout>
  <livewire:admin.requests />
</x-admin-layout>
