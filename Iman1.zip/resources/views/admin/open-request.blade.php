@section('title', 'Requested Assets')
<x-admin-layout>
  <livewire:admin.open-request />
</x-admin-layout>
