@section('title', 'Borrowers')
<x-admin-layout>
  <livewire:admin.borrower />
</x-admin-layout>
