@section('title', 'Assets')
<x-admin-layout>
  <livewire:admin.asset />
</x-admin-layout>
