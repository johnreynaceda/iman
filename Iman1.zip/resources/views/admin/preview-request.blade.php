@section('title', 'Requested Assets')
<x-admin-layout>
  <livewire:admin.preview-request />
</x-admin-layout>
