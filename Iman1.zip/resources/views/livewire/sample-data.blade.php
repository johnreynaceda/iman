<div>
  <x-button label="test" wire:click="test" />
</div>
