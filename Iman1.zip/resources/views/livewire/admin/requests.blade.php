<div>
  <div class="p-4 bg-white rounded-xl shadow">
    {{ $this->table }}
  </div>
</div>
